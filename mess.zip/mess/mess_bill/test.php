<?php

$conn = new mysqli("localhost", "root", "root123", "mess_management", 3308);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$result = $conn->query("SELECT DATABASE()");
$row = $result->fetch_row();

echo "Connected Successfully to DB: " . $row[0];

?>